<?php

function dd($pollo)
{
    echo '<pre>';
    die(var_dump($pollo));
}
