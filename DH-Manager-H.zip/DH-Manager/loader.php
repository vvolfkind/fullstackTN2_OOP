<?php
require 'helpers.php';
require 'Classes/Alumno.php';
require 'Classes/Curso.php';
require 'Classes/Profesor.php';
require 'Classes/ProfesorTitular.php';
require 'Classes/ProfesorAdjunto.php';
require 'Classes/DigitalHouseManager.php';

/**
 * 
 * No testear aca, hacer las pruebas en tests.php
 * -----------------------------------------------
 * 
 */